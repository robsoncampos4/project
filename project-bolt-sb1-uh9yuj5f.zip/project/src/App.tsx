import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Toaster } from 'react-hot-toast';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import MyPlants from './pages/MyPlants';
import PlantDetail from './pages/PlantDetail';
import Login from './pages/Login';
import { PlantProvider } from './contexts/PlantContext';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    checkUser();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsAuthenticated(!!session);
    });

    return () => subscription.unsubscribe();
  }, []);

  async function checkUser() {
    const { data: { session } } = await supabase.auth.getSession();
    setIsAuthenticated(!!session);
  }

  if (!isAuthenticated) {
    return (
      <>
        <Toaster position="top-right" />
        <Login onLogin={() => setIsAuthenticated(true)} />
      </>
    );
  }

  return (
    <Router>
      <PlantProvider>
        <div className="min-h-screen bg-gray-50">
          <Toaster position="top-right" />
          <Header />
          <div className="flex">
            <Sidebar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/plantas" element={<MyPlants />} />
                <Route path="/plantas/:id" element={<PlantDetail />} />
                <Route path="*" element={<Navigate to="/\" replace />} />
              </Routes>
            </main>
          </div>
        </div>
      </PlantProvider>
    </Router>
  );
}

export default App;