import { Plant } from '../types';

export const plantsData: Plant[] = [
  {
    id: '1',
    name: 'Monstera Deliciosa',
    species: 'Monstera',
    image: 'https://images.pexels.com/photos/3097770/pexels-photo-3097770.jpeg',
    healthScore: 92,
    lastWatered: '2025-05-10',
    nextWatering: '2025-05-17',
    location: 'Living Room',
    wateringFrequency: 7,
    lightRequirement: 'medium',
    humidity: 'high',
    temperature: {
      min: 18,
      max: 30,
    },
    notes: 'Thriving well near the east-facing window',
  },
  {
    id: '2',
    name: 'Peace Lily',
    species: 'Spathiphyllum',
    image: 'https://images.pexels.com/photos/4751969/pexels-photo-4751969.jpeg',
    healthScore: 78,
    lastWatered: '2025-05-12',
    nextWatering: '2025-05-16',
    location: 'Bedroom',
    wateringFrequency: 4,
    lightRequirement: 'low',
    humidity: 'medium',
    temperature: {
      min: 18,
      max: 24,
    },
    notes: 'Leaves slightly drooping, might need more water',
  },
  {
    id: '3',
    name: 'Snake Plant',
    species: 'Sansevieria',
    image: 'https://images.pexels.com/photos/2123482/pexels-photo-2123482.jpeg',
    healthScore: 95,
    lastWatered: '2025-05-01',
    nextWatering: '2025-05-21',
    location: 'Office',
    wateringFrequency: 20,
    lightRequirement: 'low',
    humidity: 'low',
    temperature: {
      min: 16,
      max: 29,
    },
    notes: 'Very resilient, perfect for office environment',
  },
  {
    id: '4',
    name: 'Fiddle Leaf Fig',
    species: 'Ficus lyrata',
    image: 'https://images.pexels.com/photos/6957650/pexels-photo-6957650.jpeg',
    healthScore: 65,
    lastWatered: '2025-05-08',
    nextWatering: '2025-05-15',
    location: 'Living Room',
    wateringFrequency: 7,
    lightRequirement: 'high',
    humidity: 'medium',
    temperature: {
      min: 18,
      max: 27,
    },
    notes: 'New growth appearing, but some lower leaves showing brown spots',
  },
];

export const user = {
  name: 'Dani alves',
  avatar: 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSqtHNErg2BVe1eSgU2SvmmsKxXYUkep4w2KBRc-52qfQ5shjNl_FieghTS8gZL6rUVya--JH6UZyDefzLIoluqvQ',
  plantsCount: plantsData.length,
  location: 'New York, NY',
};

export const weatherData = {
  temperature: 24,
  humidity: 65,
  forecast: 'sunny' as const,
};