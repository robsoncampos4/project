import React from 'react';
import { usePlants } from '../contexts/PlantContext';
import { 
  ArrowLeft, 
  Droplet, 
  Sun, 
  ThermometerSun, 
  Wind, 
  Calendar, 
  Edit3, 
  Trash2, 
  Share2,
  Leaf
} from 'lucide-react';
import HealthIndicator from '../components/ui/HealthIndicator';
import Button from '../components/ui/Button';

type PlantDetailProps = {
  plantId: string;
  onBack: () => void;
};

const PlantDetail: React.FC<PlantDetailProps> = ({ plantId, onBack }) => {
  const { getPlantById } = usePlants();
  const plant = getPlantById(plantId);
  
  if (!plant) {
    return <div>Plant not found</div>;
  }
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };
  
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
      <button 
        onClick={onBack}
        className="flex items-center text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="h-5 w-5 mr-1" />
        <span>Back to dashboard</span>
      </button>
      
      <div className="bg-white shadow-sm rounded-xl overflow-hidden">
        <div className="h-64 relative">
          <img 
            src={plant.image} 
            alt={plant.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-6 text-white">
            <h1 className="text-3xl font-bold">{plant.name}</h1>
            <p className="text-gray-200">{plant.species}</p>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-8">
            <div className="mb-4 sm:mb-0">
              <h2 className="text-lg font-semibold text-gray-800 mb-1">Health Status</h2>
              <HealthIndicator score={plant.healthScore} size="lg" />
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Edit3 className="h-4 w-4 mr-1" />
                Edit
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
              <Button variant="outline" size="sm">
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-green-50 rounded-lg p-4">
              <h3 className="text-md font-semibold text-gray-800 mb-3">Care Information</h3>
              
              <div className="space-y-3">
                <div className="flex items-start">
                  <Droplet className="h-5 w-5 text-blue-500 mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-gray-700">Watering</p>
                    <p className="text-sm text-gray-600">Every {plant.wateringFrequency} days</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Sun className="h-5 w-5 text-amber-500 mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-gray-700">Light</p>
                    <p className="text-sm text-gray-600">{plant.lightRequirement.charAt(0).toUpperCase() + plant.lightRequirement.slice(1)} light required</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Wind className="h-5 w-5 text-teal-500 mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-gray-700">Humidity</p>
                    <p className="text-sm text-gray-600">{plant.humidity.charAt(0).toUpperCase() + plant.humidity.slice(1)} humidity preferred</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <ThermometerSun className="h-5 w-5 text-red-500 mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-gray-700">Temperature</p>
                    <p className="text-sm text-gray-600">{plant.temperature.min}°C - {plant.temperature.max}°C</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-md font-semibold text-gray-800 mb-3">Watering Schedule</h3>
              
              <div className="bg-blue-50 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-blue-500 mr-2" />
                    <span className="text-gray-700">Last watered</span>
                  </div>
                  <span className="font-medium">{formatDate(plant.lastWatered)}</span>
                </div>
              </div>
              
              <div className="bg-green-50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Next watering</span>
                  </div>
                  <span className="font-medium">{formatDate(plant.nextWatering)}</span>
                </div>
              </div>
              
              <div className="mt-6">
                <h3 className="text-md font-semibold text-gray-800 mb-2">Location</h3>
                <p className="text-gray-600">{plant.location}</p>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-md font-semibold text-gray-800 mb-2">Notes</h3>
            <p className="text-gray-600 bg-gray-50 p-4 rounded-lg">{plant.notes}</p>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center">
              <Leaf className="h-5 w-5 text-green-600 mr-2" />
              <h3 className="text-md font-semibold text-gray-800">AI Recommendations</h3>
            </div>
            <p className="mt-2 text-gray-600 bg-purple-50 p-4 rounded-lg">
              Based on recent data, your {plant.name} is doing well. To maintain optimal health, consider increasing humidity slightly as we approach drier months. The current watering schedule seems appropriate based on soil moisture readings.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlantDetail;