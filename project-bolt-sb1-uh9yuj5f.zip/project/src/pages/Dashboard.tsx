import React from 'react';
import { usePlants } from '../contexts/PlantContext';
import PlantCard from '../components/PlantCard';
import WeatherCard from '../components/Dashboard/WeatherCard';
import WateringSchedule from '../components/Dashboard/WateringSchedule';
import HealthSummary from '../components/Dashboard/HealthSummary';
import AIRecommendations from '../components/Dashboard/AIRecommendations';
import { Plane as Plant2, Search } from 'lucide-react';
import { user } from '../data/plants';

const Dashboard: React.FC = () => {
  const { plants, weatherData } = usePlants();
  const [selectedPlantId, setSelectedPlantId] = React.useState<string | null>(null);

  const handlePlantClick = (id: string) => {
    setSelectedPlantId(id);
    // In a real app, this would navigate to a detailed plant view
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Welcome back, {user.name.split(' ')[0]}</h2>
          <p className="text-gray-600 mt-1">You have {plants.length} plants in your garden</p>
        </div>
        
        <div className="mt-4 md:mt-0 relative rounded-md w-full md:w-64">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
            placeholder="Search plants..."
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <WeatherCard weatherData={weatherData} />
          
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                <Plant2 className="h-5 w-5 text-green-600 mr-2" />
                Your Plants
              </h3>
              <button className="text-sm text-green-600 font-medium hover:text-green-700">
                View all
              </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
              {plants.slice(0, 4).map(plant => (
                <PlantCard 
                  key={plant.id} 
                  plant={plant} 
                  onClick={handlePlantClick}
                />
              ))}
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          <HealthSummary plants={plants} />
          <WateringSchedule plants={plants} />
          <AIRecommendations plants={plants} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;