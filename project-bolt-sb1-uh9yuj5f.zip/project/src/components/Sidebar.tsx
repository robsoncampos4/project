import React from 'react';
import { Home, Plane as Plant, CloudRain, AlertTriangle, Database, Settings, HelpCircle, PlusCircle } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

type SidebarItemProps = {
  icon: React.ReactNode;
  label: string;
  to: string;
  alert?: boolean;
};

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, to, alert = false }) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link 
      to={to}
      className={`flex items-center px-4 py-3 rounded-lg cursor-pointer transition-colors ${
        isActive 
          ? 'bg-green-100 text-green-800' 
          : 'text-gray-600 hover:bg-gray-100'
      }`}
    >
      <div className="relative">
        {icon}
        {alert && (
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        )}
      </div>
      <span className="ml-3 font-medium">{label}</span>
    </Link>
  );
};

const Sidebar: React.FC = () => {
  return (
    <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 p-4">
      <div className="mb-8">
        <button className="w-full flex items-center justify-center py-2 px-4 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
          <PlusCircle className="w-5 h-5 mr-2" />
          <span>Adicionar Planta</span>
        </button>
      </div>
      
      <nav className="space-y-1">
        <SidebarItem icon={<Home className="w-5 h-5" />} label="Início" to="/" />
        <SidebarItem icon={<Plant className="w-5 h-5" />} label="Minhas Plantas" to="/plantas" />
        <SidebarItem icon={<CloudRain className="w-5 h-5" />} label="Agenda de Rega" to="/agenda" />
        <SidebarItem icon={<AlertTriangle className="w-5 h-5" />} label="Alertas de Saúde" to="/alertas" alert />
        <SidebarItem icon={<Database className="w-5 h-5" />} label="Banco de Plantas" to="/banco" />
      </nav>
      
      <div className="mt-auto space-y-1">
        <SidebarItem icon={<Settings className="w-5 h-5" />} label="Configurações" to="/configuracoes" />
        <SidebarItem icon={<HelpCircle className="w-5 h-5" />} label="Ajuda" to="/ajuda" />
      </div>
    </aside>
  );
};

export default Sidebar;