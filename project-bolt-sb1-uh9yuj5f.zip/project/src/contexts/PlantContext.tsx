import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Plant, WeatherData } from '../types';
import { plantsData, weatherData as initialWeatherData } from '../data/plants';

type PlantContextType = {
  plants: Plant[];
  addPlant: (plant: Plant) => void;
  updatePlant: (plant: Plant) => void;
  deletePlant: (id: string) => void;
  getPlantById: (id: string) => Plant | undefined;
  weatherData: WeatherData;
};

const PlantContext = createContext<PlantContextType | undefined>(undefined);

export const PlantProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [plants, setPlants] = useState<Plant[]>(plantsData);
  const [weatherData] = useState<WeatherData>(initialWeatherData);

  const addPlant = (plant: Plant) => {
    setPlants([...plants, plant]);
  };

  const updatePlant = (updatedPlant: Plant) => {
    setPlants(plants.map(plant => 
      plant.id === updatedPlant.id ? updatedPlant : plant
    ));
  };

  const deletePlant = (id: string) => {
    setPlants(plants.filter(plant => plant.id !== id));
  };

  const getPlantById = (id: string) => {
    return plants.find(plant => plant.id === id);
  };

  return (
    <PlantContext.Provider value={{ 
      plants, 
      addPlant, 
      updatePlant, 
      deletePlant, 
      getPlantById,
      weatherData
    }}>
      {children}
    </PlantContext.Provider>
  );
};

export const usePlants = () => {
  const context = useContext(PlantContext);
  if (context === undefined) {
    throw new Error('usePlants must be used within a PlantProvider');
  }
  return context;
};